package com.example.cacabrecho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Main6Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_6);
    }
    public void Review (View view) {
        Intent review = new Intent(getApplicationContext(), Main7Activity.class);
        startActivity(review);
    }

    public void Salvar (View view) {
        Intent salvar = new Intent(getApplicationContext(), Main5Activity.class);
        startActivity(salvar);
    }

    public void Voltar (View view) {
        Intent voltar = new Intent(getApplicationContext(), Main4Activity.class);
        startActivity(voltar);
    }
}