package com.example.cacabrecho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void Logar(View view) {
        Intent logar = new Intent(getApplicationContext(), Main8Activity.class);
        startActivity(logar);
    }

    public void Voltar (View view) {
        Intent voltar = new Intent(getApplicationContext(), Main1Activity.class);
        startActivity(voltar);
    }

}
