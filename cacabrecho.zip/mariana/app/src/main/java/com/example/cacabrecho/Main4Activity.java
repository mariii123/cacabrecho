package com.example.cacabrecho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_4);
    }
    public void Home (View view) {
        Intent home = new Intent(getApplicationContext(), Main4Activity.class);
        startActivity(home);
    }

    public void Perfil (View view) {
        Intent perfil = new Intent(getApplicationContext(), Main8Activity.class);
        startActivity(perfil);
    }

    public void Salvos (View view) {
        Intent salvos = new Intent(getApplicationContext(), Main5Activity.class);
        startActivity(salvos);
    }

    public void Local (View view) {
        Intent local = new Intent(getApplicationContext(), Main6Activity.class);
        startActivity(local);
    }
}