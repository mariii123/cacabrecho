package com.example.cacabrecho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.Random;

public class Main1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);
    }

    public void Logar(View view) {
        Intent logar = new Intent(getApplicationContext(), Main8Activity.class);
        startActivity(logar);

    }

    public void Cadastrar(View view) {
        Intent cadastrar = new Intent(getApplicationContext(), Main3Activity.class);
        startActivity(cadastrar);
    }

}
